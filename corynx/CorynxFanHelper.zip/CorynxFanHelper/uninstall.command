#!/bin/bash
# Remove the Corynx Fan Helper and return fans to full macOS control.
set -e
LABEL="com.mwsupplylimited.corynx.fanhelper"
DEST="/Library/Application Support/Corynx"
PLIST="/Library/LaunchDaemons/$LABEL.plist"
SRC="$(cd "$(dirname "$0")" && pwd)"

if [ "$EUID" -ne 0 ]; then
    osascript -e "do shell script \"/bin/bash \\\"$SRC/uninstall.command\\\"\" with administrator privileges" \
        && echo "Done. You can close this window." || echo "Uninstall cancelled."
    exit 0
fi

echo "Removing Corynx Fan Helper…"
# Hand fans back to macOS Auto before tearing the daemon down.
curl -s --max-time 2 -X POST "http://127.0.0.1:53844/auto" >/dev/null 2>&1 || true
launchctl bootout system "$PLIST" 2>/dev/null || true
rm -f "$PLIST"
rm -f "$DEST/corynxfanhelper"
echo "✅ Removed. Your fans are back under full macOS automatic control."
