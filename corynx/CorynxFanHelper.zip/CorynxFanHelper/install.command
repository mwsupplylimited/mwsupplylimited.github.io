#!/bin/bash
# Corynx Fan Helper installer. Double-click (right-click ▸ Open the first time, since
# Gatekeeper quarantines downloaded scripts), then enter your password in the dialog.
# It installs a small background helper (root LaunchDaemon) that Corynx sends fan
# commands to. Boost-only + safe: starts in macOS Auto, reverts to Auto on quit/crash.
set -e
LABEL="com.mwsupplylimited.corynx.fanhelper"
DEST="/Library/Application Support/Corynx"
PLIST="/Library/LaunchDaemons/$LABEL.plist"
SRC="$(cd "$(dirname "$0")" && pwd)"

# Re-launch ourselves as root via the macOS password dialog if needed.
if [ "$EUID" -ne 0 ]; then
    osascript -e "do shell script \"/bin/bash \\\"$SRC/install.command\\\"\" with administrator privileges" \
        && echo "Done. You can close this window." || echo "Install cancelled."
    exit 0
fi

echo "Installing Corynx Fan Helper…"
mkdir -p "$DEST"
cp "$SRC/corynxfanhelper" "$DEST/corynxfanhelper"
xattr -cr "$DEST/corynxfanhelper" 2>/dev/null || true     # clear download quarantine
chown root:wheel "$DEST/corynxfanhelper"
chmod 755 "$DEST/corynxfanhelper"
cp "$SRC/$LABEL.plist" "$PLIST"
chown root:wheel "$PLIST"
chmod 644 "$PLIST"
launchctl bootout system "$PLIST" 2>/dev/null || true
launchctl bootstrap system "$PLIST"
echo "✅ Installed and running. Open Corynx ▸ Fans to control your fans."
